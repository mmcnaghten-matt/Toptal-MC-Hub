
## Plan: Update AI Accelerators on Way of Working page

### Changes to `src/pages/WayOfWorking.tsx`

**1. Remove accelerator**
Delete the `Toptal MC - Account Plan Insights` entry from the `accelerators` array.

**2. Add blue AI Agent icon before each name**
- Import `Bot` from `lucide-react` (standard lucide icon representing an AI agent/bot).
- In the accelerators grid, render `<Bot className="h-4 w-4 text-primary shrink-0" />` immediately before the accelerator name inside the `<h4>` for both internal (`Link`) and external (`<a>`) cards.
- The existing trailing `ArrowRight` icon stays as-is.

### Files
- `src/pages/WayOfWorking.tsx` (only file)
